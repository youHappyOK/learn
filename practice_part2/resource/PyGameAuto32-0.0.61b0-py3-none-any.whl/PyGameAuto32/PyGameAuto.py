# !/usr/bin/env python
# -*-coding:utf-8 -*-
def XpDict(item):
    pass


def xpDict(item):
    pass


def Point(x, y):
    pass


class Dm:
    def register(self):
        pass

    def Create(self):
        pass

    def Ver(self):
        pass

    def RegisterVip(self, *args):
        pass

    def SetShowErrorMsg(self, *args):
        pass

    def SetPath(self, *args):
        pass

    def IsBind(self, *args):
        pass

    def SetDict(self, *args):
        pass

    def EnumWindow(self, *args):
        pass

    def GetWindow(self, *args):
        pass

    def MoveWindow(self, *args):
        pass

    def BindWindow(self, *args):
        pass

    def BindWindowEx(self, *args):
        pass

    def SetWindowState(self, *args):
        pass

    def UnBindWindow(self):
        pass

    def FetchWord(self, *args):
        pass

    def IsDisplayDead(self, *args):
        pass

    def FindPic(self, *args):
        pass

    def CmpColor(self, *args):
        pass

    def FindColor(self, *args):
        pass

    def FindMultiColor(self, *args):
        pass

    def KeyPress(self, *args):
        pass

    def MoveTo(self, *args):
        pass

    def LeftClick(self):
        pass

    def LeftDown(self):
        pass

    def LeftUp(self):
        pass

    def SendString(self, *args):
        pass

    def FindStrFast(self, *args):
        pass

    def Ocr(self, *args):
        pass

    def slide(self, *args):
        pass


class Custom:
    def __init__(self):
        self.dm = Dm()
        self.thread = Thread()
        self.hwnd = None
        self.title = None
        self.account = None
        self.password = None
        self.service = None
        self.task_list = None
        self.progress = None
        self.py = PyGameAuto()
        self.point = None

    def clear(self):
        pass


def tdi():
    re = [Custom()]
    return re


gl_info = Custom()
td_info = tdi()


class Action:
    def __init__(self, *args, mode=1):
        pass

    def click(self, *args):
        return self

    def rclick(self, *args):
        return self

    def keypress(self, *args):
        return self

    def keydown(self, *args):
        return self

    def keyup(self, *args):
        return self

    def sleep(self, *args):
        return self

    def input(self, *args):
        return self

    def func(self, func, args=(), kwargs={}):
        return self

    def loop(self, *args):
        return self

    def loop_line(self, *args):
        return self

    def f(self, *args):
        return self

    def interval(self, *args):
        return self

    def offset(self, off, mode):
        return self

    def location(self, args):
        return self

    def s(self, *args):
        return self

    def cs(self, *args):
        return self

    def slide(self, *args, down_time, up_time, flag):
        return self

    def sfind(self, *args):
        return self

    def before(self, func, args=(), kwargs={}):
        return self

    def before_flush(self, *args):
        return self

    def flush(self, *args):
        return self

    def after(self, func, args=(), kwargs={}):
        return self

    def unfind(self, func, args=(), kwargs={}):
        return self

    def excepts(self, *args, mode):
        return self


class PyGameAuto:
    @classmethod
    def gl_init(cls, reg_code, ver_info):
        return Dm()

    def td_init(self, num):
        return Dm()

    @classmethod
    def get_path(cls):
        pass

    def set_level(self, *args):
        return self

    def set_win(self, *args):
        return self

    def set_hwnd(self, *args):
        return self

    def set_path(self, *args):
        return self

    def set_dict(self, *args):
        return self

    def set_offset(self, *args):
        return self

    def set_interval(self, *args):
        return self

    def cs(self, *args):
        return self

    def run(self, *args, num=0, start_time=0, end_time=0, flag=True):
        pass

    def run_action(self, *args, num=1, start_time=0, end_time=0, flag=True):
        pass

    def get_point(self, *args):
        pass

    def get_ocr(self, *args):
        pass

    def file(self, file_path, encoding=None, split=None):
        pass

    def read(self, *args, excepts=None, include=None):
        pass

    def write(self, *args, finish=None):
        pass


class SThread:
    def __init__(self, target=None, args=(), kwargs=None, num=None, delay=None):
        pass

    def start(self, *args):
        pass

    def stop(self, *args):
        pass

    def pause(self, *args):
        pass

    def resume(self, *args):
        pass


class Thread:
    handle = None

    def __init__(self, target=None, args=(), kwargs=None):
        pass

    def start(self):
        pass

    def stop(self):
        pass

    def pause(self):
        pass

    def resume(self):
        pass


class UI:
    def __init__(self, *args):
        pass

    def custom(self, *args):
        pass

    def clicked(self, *args):
        pass

    def text(self, *args):
        pass

    def setText(self, *args):
        pass

    def clearText(self, *args):
        pass

    def isChecked(self, *args):
        pass

    def setChecked(self, *args):
        pass

    def setIndex(self, *args):
        pass

    def checkedButton(self):
        pass

    def buttons(self):
        pass

    def setEnabled(self, *args):
        pass

    def close(self, *args):
        pass


def UINew(w=None, h=None, title=None, id=None):
    pass


def UIShow(*args):
    pass


class UIHLayout:
    def __init__(self, id=None, parent=None):
        pass


class UIVLayout:
    def __init__(self, id=None, parent=None):
        pass


class UIGroup:
    def __init__(self, id=None, text=None, parent=None):
        pass


class UILabel:
    def __init__(self, id=None, text=None, parent=None, move=None, size=None):
        pass


class UIEdit:
    def __init__(self, id=None, text=None, parent=None, move=None, size=None):
        pass


class UIButton:
    def __init__(self, id=None, text=None, parent=None, move=None, size=None):
        pass


class UITextArea:
    def __init__(self, id=None, text=None, parent=None, move=None, size=None):
        pass


class UIRadio:
    def __init__(self, id=None, text=None, parent=None):
        pass


class UICheck:
    def __init__(self, id=None, text=None, parent=None):
        pass


class UICombo:
    def __init__(self, id=None, text=None, parent=None, move=None, size=None):
        pass


class UITab:
    def __init__(self, id=None, text=None, parent=None, move=None, size=None):
        pass


class UITable:
    def __init__(self, id=None, text=None, parent=None, move=None, size=None):
        pass
